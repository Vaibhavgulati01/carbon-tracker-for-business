const { GoogleGenerativeAI } = require('@google/generative-ai');

// Initialize Gemini AI
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

/**
 * Generate emission insights based on organization data
 * @param {object} data - Organization emission data
 * @returns {object} - AI-generated insights
 */
async function generateInsights(data) {
    const prompt = `You are an expert carbon emissions analyst. Analyze the following emission data for a ${data.industry} company and provide actionable insights.

EMISSION DATA:
- Total Emissions: ${data.totalEmissions.toFixed(2)} kg CO2e (${(data.totalEmissions / 1000).toFixed(2)} tonnes)
- Scope 1 (Direct): ${data.scope1.toFixed(2)} kg CO2e (${data.scope1Percentage}%)
- Scope 2 (Energy): ${data.scope2.toFixed(2)} kg CO2e (${data.scope2Percentage}%)
- Scope 3 (Value Chain): ${data.scope3.toFixed(2)} kg CO2e (${data.scope3Percentage}%)

TOP EMISSION SOURCES:
${data.hotspots.map((h, i) => `${i + 1}. ${h.source}: ${h.kg.toFixed(2)} kg CO2e (${h.percentage}%)`).join('\n')}

Employee Count: ${data.employeeCount || 'Not specified'}

Provide your analysis in the following JSON format:
{
  "summary": "2-3 sentence summary of overall emissions profile",
  "keyFindings": ["finding1", "finding2", "finding3"],
  "recommendations": [
    {"action": "action description", "potentialReduction": "X%", "priority": "high/medium/low"},
    {"action": "action description", "potentialReduction": "X%", "priority": "high/medium/low"}
  ],
  "industryComparison": "How this compares to industry average",
  "quickWins": ["quick win 1", "quick win 2"]
}

Respond ONLY with valid JSON, no markdown or additional text.`;

    try {
        const result = await model.generateContent(prompt);
        const response = result.response.text();

        // Parse JSON response
        const cleanResponse = response.replace(/```json\n?|\n?```/g, '').trim();
        return JSON.parse(cleanResponse);
    } catch (error) {
        console.error('Gemini AI Error:', error);
        return {
            summary: 'Unable to generate AI insights at this time.',
            keyFindings: ['Analysis temporarily unavailable'],
            recommendations: [],
            industryComparison: 'Comparison unavailable',
            quickWins: []
        };
    }
}

/**
 * Simulate what-if scenarios
 * @param {object} currentData - Current emission data
 * @param {object} scenario - Scenario parameters
 * @returns {object} - Scenario analysis
 */
async function simulateScenario(currentData, scenario) {
    const prompt = `You are a carbon emissions scenario analyst. Based on the current emission data and the proposed scenario, predict the impact.

CURRENT EMISSIONS:
- Total: ${currentData.totalEmissions.toFixed(2)} kg CO2e
- Scope 1: ${currentData.scope1.toFixed(2)} kg CO2e
- Scope 2: ${currentData.scope2.toFixed(2)} kg CO2e
- Scope 3: ${currentData.scope3.toFixed(2)} kg CO2e

SCENARIO TO ANALYZE:
${scenario.description}

Parameters:
${Object.entries(scenario.parameters || {}).map(([k, v]) => `- ${k}: ${v}`).join('\n')}

Provide a detailed analysis in the following JSON format:
{
  "scenarioName": "Brief name for this scenario",
  "predictedReduction": {
    "percentage": X,
    "kgCO2e": X,
    "tonnesCO2e": X
  },
  "newTotals": {
    "total": X,
    "scope1": X,
    "scope2": X,
    "scope3": X
  },
  "implementation": {
    "difficulty": "easy/medium/hard",
    "timeframe": "short-term/medium-term/long-term",
    "estimatedCost": "low/medium/high"
  },
  "benefits": ["benefit1", "benefit2"],
  "challenges": ["challenge1", "challenge2"],
  "nextSteps": ["step1", "step2"]
}

Respond ONLY with valid JSON, no markdown or additional text.`;

    try {
        const result = await model.generateContent(prompt);
        const response = result.response.text();

        const cleanResponse = response.replace(/```json\n?|\n?```/g, '').trim();
        return JSON.parse(cleanResponse);
    } catch (error) {
        console.error('Gemini Scenario Error:', error);
        return {
            scenarioName: scenario.description,
            predictedReduction: { percentage: 0, kgCO2e: 0, tonnesCO2e: 0 },
            newTotals: currentData,
            implementation: { difficulty: 'unknown', timeframe: 'unknown', estimatedCost: 'unknown' },
            benefits: ['Unable to analyze'],
            challenges: ['Analysis temporarily unavailable'],
            nextSteps: []
        };
    }
}

/**
 * Generate reduction recommendations
 * @param {object} data - Emission data
 * @returns {object} - Reduction strategies
 */
async function generateRecommendations(data) {
    const prompt = `You are a sustainability consultant. Based on the emission profile, suggest specific reduction strategies.

EMISSION PROFILE:
- Industry: ${data.industry}
- Total Emissions: ${data.totalEmissions.toFixed(2)} kg CO2e
- Top Sources: ${data.hotspots.slice(0, 5).map(h => h.source).join(', ')}
- Scope with highest emissions: Scope ${data.highestScope}

Provide 5 actionable recommendations in JSON format:
{
  "recommendations": [
    {
      "title": "Short title",
      "description": "Detailed description",
      "category": "Energy/Transport/Waste/Procurement/Operations",
      "targetScope": 1/2/3,
      "estimatedReduction": "X-Y%",
      "implementation": "How to implement",
      "timeline": "X months",
      "roi": "low/medium/high"
    }
  ]
}

Respond ONLY with valid JSON.`;

    try {
        const result = await model.generateContent(prompt);
        const response = result.response.text();

        const cleanResponse = response.replace(/```json\n?|\n?```/g, '').trim();
        return JSON.parse(cleanResponse);
    } catch (error) {
        console.error('Gemini Recommendations Error:', error);
        return { recommendations: [] };
    }
}

module.exports = {
    generateInsights,
    simulateScenario,
    generateRecommendations
};
